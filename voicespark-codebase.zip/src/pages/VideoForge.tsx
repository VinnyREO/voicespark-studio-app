import { useState, useCallback, useEffect } from 'react';
import { useVideoEditor } from '@/hooks/useVideoEditor';
import { useKeyboardShortcuts } from '@/hooks/useKeyboardShortcuts';
import { ToolPanel } from '@/components/video-editor/ToolPanel';
import { PreviewCanvas } from '@/components/video-editor/PreviewCanvas';
import { Timeline } from '@/components/video-editor/Timeline';
import { MediaAsset } from '@/types/video-editor';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function VideoForge() {
  const editor = useVideoEditor();
  const [snapEnabled, setSnapEnabled] = useState(true);
  const [draggedAsset, setDraggedAsset] = useState<MediaAsset | null>(null);
  const [isDraggingExternal, setIsDraggingExternal] = useState(false);
  const [timelineHeight, setTimelineHeight] = useState(288); // 72 * 4 = 288px default (h-72 = 18rem = 288px)
  const [isResizingTimeline, setIsResizingTimeline] = useState(false);
  const [mediaPanelWidth, setMediaPanelWidth] = useState(320); // Default 320px (w-80)
  const [isMediaPanelCollapsed, setIsMediaPanelCollapsed] = useState(false);
  const [isResizingMediaPanel, setIsResizingMediaPanel] = useState(false);

  // Helper to process a single file and return the asset
  const processSingleFile = useCallback(async (file: File): Promise<MediaAsset | null> => {
    let type: 'video' | 'audio' | 'image';

    if (file.type.startsWith('video/')) type = 'video';
    else if (file.type.startsWith('audio/')) type = 'audio';
    else if (file.type.startsWith('image/')) type = 'image';
    else {
      toast.error(`Unsupported file type: ${file.name}`);
      return null;
    }

    const generateId = () => `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const src = URL.createObjectURL(file);

    // Generate thumbnail
    const thumbnail = await new Promise<string>((resolve) => {
      if (type === 'video' || type === 'image') {
        const el = type === 'video' ? document.createElement('video') : new Image();
        el.src = src;

        if (type === 'video') {
          (el as HTMLVideoElement).onloadedmetadata = () => {
            (el as HTMLVideoElement).currentTime = 0.5;
          };
          (el as HTMLVideoElement).onseeked = () => {
            const canvas = document.createElement('canvas');
            canvas.width = 160;
            canvas.height = 90;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(el as HTMLVideoElement, 0, 0, canvas.width, canvas.height);
              resolve(canvas.toDataURL());
            }
          };
        } else {
          (el as HTMLImageElement).onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = 160;
            canvas.height = 90;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(el as HTMLImageElement, 0, 0, canvas.width, canvas.height);
              resolve(canvas.toDataURL());
            }
          };
        }
      } else {
        resolve('');
      }
    });

    // Get duration
    const duration = await new Promise<number | undefined>((resolve) => {
      if (type === 'video') {
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.onloadedmetadata = () => {
          resolve(video.duration);
          URL.revokeObjectURL(video.src);
        };
        video.src = src;
      } else if (type === 'audio') {
        const audio = new Audio();
        audio.preload = 'metadata';
        audio.onloadedmetadata = () => {
          resolve(audio.duration);
          URL.revokeObjectURL(audio.src);
        };
        audio.src = src;
      } else {
        resolve(undefined);
      }
    });

    const asset: MediaAsset = {
      id: generateId(),
      type,
      name: file.name,
      src,
      thumbnail,
      duration,
      file,
    };

    editor.addAsset(asset);
    return asset;
  }, [editor]);

  // Helper to process multiple dropped files
  const processFiles = useCallback(async (files: FileList) => {
    for (let i = 0; i < files.length; i++) {
      await processSingleFile(files[i]);
    }

    toast.success(`Added ${files.length} file${files.length > 1 ? 's' : ''}`);
  }, [processSingleFile]);

  const handleDropAsset = useCallback((asset: MediaAsset, trackIndex: number, timePosition: number) => {
    console.log('📍 Dropping asset to timeline:', {
      assetId: asset.id,
      assetName: asset.name,
      assetType: asset.type,
      assetSrc: asset.src ? asset.src.substring(0, 50) + '...' : 'no src',
      trackIndex,
      timePosition,
      duration: asset.duration,
      allAssets: editor.state.assets.map(a => ({ id: a.id, name: a.name, type: a.type }))
    });

    // Use exact asset duration for videos/audio, default 3 seconds for images
    const clipDuration = asset.duration || (asset.type === 'image' ? 3 : 5);

    editor.addClip({
      assetId: asset.id,
      trackIndex,
      startTime: timePosition,
      duration: clipDuration,
      trimStart: 0,
      trimEnd: 0,
    });
  }, [editor]);

  // Handle external file drop on timeline
  const handleDropExternalFile = useCallback(async (file: File, trackIndex: number, timePosition: number) => {
    console.log('📥 Dropping external file to timeline:', file.name);

    const asset = await processSingleFile(file);
    if (asset) {
      // Use exact asset duration for videos/audio, default 3 seconds for images
      const clipDuration = asset.duration || (asset.type === 'image' ? 3 : 5);

      editor.addClip({
        assetId: asset.id,
        trackIndex,
        startTime: timePosition,
        duration: clipDuration,
        trimStart: 0,
        trimEnd: 0,
      });
      toast.success(`Added ${file.name} to timeline`);
    }
  }, [processSingleFile, editor]);

  // Handle file drop on preview canvas
  const handleDropOnPreview = useCallback(async (file: File) => {
    console.log('📥 Dropping file on preview canvas:', file.name);

    const asset = await processSingleFile(file);
    if (asset) {
      // Use exact asset duration for videos/audio, default 3 seconds for images
      const clipDuration = asset.duration || (asset.type === 'image' ? 3 : 5);

      // Add clip to track 0 at current playhead position
      editor.addClip({
        assetId: asset.id,
        trackIndex: 0,
        startTime: editor.state.playheadPosition,
        duration: clipDuration,
        trimStart: 0,
        trimEnd: 0,
      });
      toast.success(`Added ${file.name} to Track 1`);
    }
  }, [processSingleFile, editor]);

  // Handle quick add to timeline from media panel
  const handleAddToTimeline = useCallback((asset: MediaAsset) => {
    const clipDuration = asset.duration || (asset.type === 'image' ? 3 : 5);

    // Add to track 0 at the end of existing content
    const lastClipEnd = editor.state.clips.length > 0
      ? Math.max(...editor.state.clips.map(c => c.startTime + c.duration))
      : 0;

    editor.addClip({
      assetId: asset.id,
      trackIndex: 0,
      startTime: lastClipEnd,
      duration: clipDuration,
      trimStart: 0,
      trimEnd: 0,
    });

    toast.success(`Added ${asset.name} to timeline`);
  }, [editor]);

  // Handle media panel resize
  useEffect(() => {
    if (!isResizingMediaPanel) return;

    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = Math.max(250, Math.min(e.clientX, 600)); // Min 250px, max 600px
      setMediaPanelWidth(newWidth);
    };

    const handleMouseUp = () => {
      setIsResizingMediaPanel(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizingMediaPanel]);

  const handleSeekLeft = useCallback(() => {
    const frameTime = 1 / 30; // 30fps
    editor.setPlayheadPosition(Math.max(0, editor.state.playheadPosition - frameTime));
  }, [editor]);

  const handleSeekRight = useCallback(() => {
    const frameTime = 1 / 30; // 30fps
    editor.setPlayheadPosition(Math.min(editor.state.duration, editor.state.playheadPosition + frameTime));
  }, [editor]);

  // Timeline resize handlers
  const handleResizeStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizingTimeline(true);
  }, []);

  const handleResizeMove = useCallback((e: MouseEvent) => {
    if (!isResizingTimeline) return;

    // Calculate new height based on mouse position from bottom of window
    const newHeight = window.innerHeight - e.clientY;
    // Constrain between 200px and 600px
    const constrainedHeight = Math.max(200, Math.min(600, newHeight));
    setTimelineHeight(constrainedHeight);
  }, [isResizingTimeline]);

  const handleResizeEnd = useCallback(() => {
    setIsResizingTimeline(false);
  }, []);

  useEffect(() => {
    if (isResizingTimeline) {
      document.addEventListener('mousemove', handleResizeMove);
      document.addEventListener('mouseup', handleResizeEnd);
      return () => {
        document.removeEventListener('mousemove', handleResizeMove);
        document.removeEventListener('mouseup', handleResizeEnd);
      };
    }
  }, [isResizingTimeline, handleResizeMove, handleResizeEnd]);

  // Global drag and drop handlers
  useEffect(() => {
    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      if (e.dataTransfer && e.dataTransfer.types.includes('Files')) {
        setIsDraggingExternal(true);
      }
    };

    const handleDragLeave = (e: DragEvent) => {
      // Only hide overlay if leaving the window
      if (e.clientX === 0 && e.clientY === 0) {
        setIsDraggingExternal(false);
      }
    };

    const handleDrop = async (e: DragEvent) => {
      // Only process if drop event wasn't already handled by a child component
      // Child components should call e.stopPropagation() to prevent this global handler
      setIsDraggingExternal(false);

      // Check if the drop target is a specific drop zone (has data-drop-zone attribute)
      const target = e.target as HTMLElement;
      const hasDropZone = target.closest('[data-drop-zone]');

      // Only process as fallback if no specific drop zone handled it
      if (!hasDropZone && e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
        e.preventDefault();
        await processFiles(e.dataTransfer.files);
      }
    };

    window.addEventListener('dragover', handleDragOver);
    window.addEventListener('dragleave', handleDragLeave);
    window.addEventListener('drop', handleDrop);

    return () => {
      window.removeEventListener('dragover', handleDragOver);
      window.removeEventListener('dragleave', handleDragLeave);
      window.removeEventListener('drop', handleDrop);
    };
  }, [processFiles]);

  // Keyboard shortcuts
  useKeyboardShortcuts({
    onPlayPause: editor.togglePlayPause,
    onSplit: editor.splitClipAtPlayhead,
    onDelete: editor.deleteSelected,
    onCopy: editor.copySelected,
    onPaste: editor.paste,
    onUndo: editor.undo,
    onRedo: editor.redo,
    onSeekLeft: handleSeekLeft,
    onSeekRight: handleSeekRight,
    onSeekToStart: editor.seekToStart,
    onSeekToEnd: editor.seekToEnd,
  });

  return (
    <div className="h-screen bg-background videoforge-theme flex flex-col overflow-hidden">
      <style>{`
        /* Purple theme for VideoForge */
        .videoforge-theme .glow-button {
          box-shadow: 0 0 30px rgba(168, 85, 247, 0.4);
        }
        .videoforge-theme .glow-button:hover {
          box-shadow: 0 0 50px rgba(168, 85, 247, 0.6);
        }

        /* Primary filled buttons (Upload, Play) */
        .videoforge-theme button[class*="bg-primary"]:not([class*="bg-primary/"]) {
          background: #a855f7 !important;
          color: white !important;
        }
        .videoforge-theme button[class*="bg-primary"]:not([class*="bg-primary/"]):hover {
          background: #9333ea !important;
          color: white !important;
        }

        /* Primary text and borders */
        .videoforge-theme [class*="text-primary"]:not(button) {
          color: #a855f7 !important;
        }
        .videoforge-theme [class*="border-primary"] {
          border-color: #a855f7 !important;
        }
        .videoforge-theme [class*="ring-primary"] {
          --tw-ring-color: #a855f7 !important;
        }

        /* Semi-transparent purple backgrounds */
        .videoforge-theme [class*="bg-primary/"]:not(button) {
          background-color: rgba(168, 85, 247, 0.1) !important;
        }

        /* Toolbar buttons - keep subtle */
        .videoforge-theme .toolbar-btn {
          background: transparent !important;
          color: inherit !important;
        }
        .videoforge-theme .toolbar-btn:hover {
          background: rgba(168, 85, 247, 0.1) !important;
        }

        /* Snap toggle when active */
        .videoforge-theme button[data-active="true"] {
          background: rgba(168, 85, 247, 0.2) !important;
          border-color: #a855f7 !important;
          color: #a855f7 !important;
        }
      `}</style>

      {/* Header space - Fixed height */}
      <div className="h-[73px] flex-shrink-0" />

      {/* Main content area - Grows to fill space */}
      <div className="flex-1 flex overflow-hidden">
        {/* Tool Panel - Left Sidebar */}
        {!isMediaPanelCollapsed && (
          <>
            <aside
              className="bg-card/30 flex flex-col overflow-hidden flex-shrink-0 relative"
              style={{ width: `${mediaPanelWidth}px` }}
            >
              <ToolPanel
                assets={editor.state.assets}
                onAddAsset={editor.addAsset}
                onRemoveAsset={editor.removeAsset}
                onDragStart={(asset) => setDraggedAsset(asset)}
                onAddToTimeline={handleAddToTimeline}
                aspectRatio={editor.state.aspectRatio}
                onAspectRatioChange={editor.setAspectRatio}
                volume={editor.state.volume}
                onVolumeChange={editor.setVolume}
                zoomLevel={editor.state.zoomLevel}
                onZoomChange={editor.setZoomLevel}
                onClose={() => setIsMediaPanelCollapsed(true)}
              />

              {/* Resize handle */}
              <div
                className="absolute right-0 top-0 bottom-0 w-1 cursor-ew-resize hover:bg-primary/50 transition-colors group"
                onMouseDown={() => setIsResizingMediaPanel(true)}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-12 bg-zinc-700 group-hover:bg-primary transition-colors" />
              </div>
            </aside>

            {/* Vertical Divider */}
            <div className="w-1 bg-zinc-700 flex-shrink-0" />
          </>
        )}

        {/* Toggle button for media panel - Only show when collapsed */}
        {isMediaPanelCollapsed && (
          <button
            onClick={() => setIsMediaPanelCollapsed(false)}
            className="absolute left-0 top-24 z-40 p-2 bg-card border border-border rounded-r-lg shadow-lg hover:bg-accent transition-all"
            title="Show Tool Panel"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        )}

        {/* Main content - Preview and Timeline */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Preview area - Grows to fill available space */}
          <div className="flex-1 flex items-center justify-center p-4 overflow-hidden">
            <PreviewCanvas
              clips={editor.state.clips}
              assets={editor.state.assets}
              playheadPosition={editor.state.playheadPosition}
              isPlaying={editor.state.isPlaying}
              aspectRatio={editor.state.aspectRatio}
              volume={editor.state.volume}
              trackSettings={editor.state.trackSettings}
              onDropFile={handleDropOnPreview}
            />
          </div>

          {/* Horizontal Divider above Timeline - Also acts as resize handle */}
          <div
            onMouseDown={handleResizeStart}
            className={cn(
              "h-1 bg-zinc-700 w-full flex-shrink-0 cursor-ns-resize hover:bg-zinc-600 transition-colors relative group",
              isResizingTimeline && "bg-zinc-600"
            )}
          >
            {/* Visual indicator on hover */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-0.5 rounded-full bg-zinc-500 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>

          {/* Timeline - Fixed height, resizable */}
          <div
            className="flex-shrink-0 overflow-hidden relative"
            style={{ height: `${timelineHeight}px` }}
          >
            <Timeline
              clips={editor.state.clips}
              assets={editor.state.assets}
              selectedClipIds={editor.state.selectedClipIds}
              playheadPosition={editor.state.playheadPosition}
              duration={editor.state.duration}
              zoomLevel={editor.state.zoomLevel}
              aspectRatio={editor.state.aspectRatio}
              onSelectClip={editor.selectClip}
              onUpdateClip={editor.updateClip}
              onUpdateMultipleClips={editor.updateMultipleClips}
              onSetPlayhead={editor.setPlayheadPosition}
              onZoomChange={editor.setZoomLevel}
              onDropAsset={handleDropAsset}
              onDropExternalFile={handleDropExternalFile}
              onDeselectAll={editor.deselectAll}
              canUndo={editor.canUndo}
              canRedo={editor.canRedo}
              snapEnabled={snapEnabled}
              onUndo={editor.undo}
              onRedo={editor.redo}
              onCopy={editor.copySelected}
              onPaste={editor.paste}
              onDelete={editor.deleteSelected}
              onSplit={editor.splitClipAtPlayhead}
              onToggleSnap={() => setSnapEnabled(!snapEnabled)}
              isPlaying={editor.state.isPlaying}
              volume={editor.state.volume}
              onPlayPause={editor.togglePlayPause}
              onSeekToStart={editor.seekToStart}
              onSeekToEnd={editor.seekToEnd}
              onVolumeChange={editor.setVolume}
              onSplitAudio={editor.splitAudioFromVideo}
              onDuplicateClip={editor.duplicateClip}
              onDeleteClip={editor.removeClip}
              onSplitClipAtPlayhead={editor.splitClipAtPlayhead}
              trackSettings={editor.state.trackSettings}
              onTrackVolumeChange={editor.setTrackVolume}
              onTrackSpeedChange={editor.setTrackSpeed}
              onTrackVisibleChange={editor.setTrackVisible}
              onTrackMutedChange={editor.setTrackMuted}
            />
          </div>
        </main>
      </div>

      {/* Background gradient */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full blur-3xl" style={{ background: 'rgba(168, 85, 247, 0.05)' }} />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full blur-3xl" style={{ background: 'rgba(236, 72, 153, 0.05)' }} />
      </div>

      {/* Global Drag Overlay */}
      {isDraggingExternal && (
        <div className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm flex items-center justify-center pointer-events-none">
          <div className="text-center">
            <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-primary/20 border-4 border-dashed border-primary flex items-center justify-center">
              <svg className="w-12 h-12 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
            </div>
            <p className="text-2xl font-bold text-foreground">Drop files to add to library</p>
            <p className="text-sm text-muted-foreground mt-2">Video, audio, or image files</p>
          </div>
        </div>
      )}
    </div>
  );
}
