import { Waves, HelpCircle, Video } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { APIKeyInput } from './APIKeyInput';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface HeaderProps {
  apiKey: string | null;
  onSaveApiKey: (key: string) => void;
  onClearApiKey: () => void;
}

export function Header({ apiKey, onSaveApiKey, onClearApiKey }: HeaderProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const currentPath = location.pathname;

  const isVoiceForge = currentPath === '/voiceforge';
  const isVideoForge = currentPath === '/videoforge';

  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container max-w-full mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-cyan-400 flex items-center justify-center shadow-lg shadow-primary/20">
                  <Waves className="w-5 h-5 text-primary-foreground" />
                </div>
                <div className="absolute -inset-1 bg-primary/20 rounded-xl blur-md -z-10" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  VoiceSpark Studio
                </h1>
                <p className="text-xs text-muted-foreground">
                  YouTube Video Creation
                </p>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
              <button
                onClick={() => navigate('/voiceforge')}
                className={cn(
                  'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                  isVoiceForge
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground hover:bg-background/50'
                )}
              >
                <Waves className="w-4 h-4" />
                VoiceForge
              </button>
              <button
                onClick={() => navigate('/videoforge')}
                className={cn(
                  'flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                  isVideoForge
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground hover:bg-background/50'
                )}
              >
                <Video className="w-4 h-4" />
                VideoForge
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <APIKeyInput
              apiKey={apiKey}
              onSave={onSaveApiKey}
              onClear={onClearApiKey}
            />

            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground hover:text-foreground"
                >
                  <HelpCircle className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" align="end" className="max-w-xs">
                <p className="font-medium mb-1">
                  {isVoiceForge ? 'How to use VoiceForge' : 'How to use VideoForge'}
                </p>
                {isVoiceForge ? (
                  <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                    <li>Add your xAI API key</li>
                    <li>Paste or write your script</li>
                    <li>Add style tags for expression</li>
                    <li>Choose a voice and generate!</li>
                  </ol>
                ) : (
                  <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                    <li>Upload media files</li>
                    <li>Drag clips to timeline</li>
                    <li>Edit and arrange your video</li>
                    <li>Export your creation!</li>
                  </ol>
                )}
              </TooltipContent>
            </Tooltip>
          </div>
        </div>
      </div>
    </header>
  );
}
