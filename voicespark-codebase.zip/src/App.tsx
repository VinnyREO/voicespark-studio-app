import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import VoiceForge from "./pages/VoiceForge";
import VideoForge from "./pages/VideoForge";
import NotFound from "./pages/NotFound";
import { Header } from "./components/Header";
import { useLocalStorage } from "./hooks/useLocalStorage";
import { useCallback } from "react";
import { toast } from "sonner";

const queryClient = new QueryClient();

function AppContent() {
  const [apiKey, setApiKey] = useLocalStorage<string | null>('xai-api-key', null);

  const handleClearApiKey = useCallback(() => {
    setApiKey(null);
    toast.success('API key removed');
  }, [setApiKey]);

  return (
    <>
      <Header
        apiKey={apiKey}
        onSaveApiKey={setApiKey}
        onClearApiKey={handleClearApiKey}
      />
      <Routes>
        <Route path="/" element={<Navigate to="/voiceforge" replace />} />
        <Route path="/voiceforge" element={<VoiceForge />} />
        <Route path="/videoforge" element={<VideoForge />} />
        {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
